
// Add any interactive features or additional functionality here
// For example, handling form submissions, adding animations, etc.

// For now, let's add a simple form submission handling using JavaScript
document.getElementById('feedbackForm').addEventListener('submit', function (event) {
    event.preventDefault();

    // Fetch form data
    const formData = new FormData(event.target);

    // Log the form data (In a real scenario, you'd send this data to a server)
    console.log({
        name: formData.get('name'),
        email: formData.get('email'),
    });

    // You can add an AJAX request here to send the form data to your server
});
